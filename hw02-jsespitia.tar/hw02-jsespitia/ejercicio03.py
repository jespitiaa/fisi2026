for i in range(0,20,2):
    print(i)

k=1
while k < 20:
    print(k)
    k+=2

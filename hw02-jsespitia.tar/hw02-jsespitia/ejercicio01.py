a=13
b=5
c=True
d=False
a/b
#divide el valor numerico de la variable a entre el valor numerico de la variable b. El resultado es 13/5, o 2.6
a//b
#realiza la misma division que el comando de arriba, pero trunca el resultado para que se muestre un entero. El resultado es 2
a%5
#calcula el modulo en 5 de la variable a- Es decir, el residuo de la division de 13 entre 5. El resultado es 3
c=a+b
#reasigna el valor de la variable c al resultado de la suma entre los valores de a y b. Es decir, c toma el valor de 13+5. El resultado es 18
c+=b
#toma el valor de c y le suma el valor de b para reasignarlo a la variable c. Es decir c = 18 + 5. El resultado es 23
c*=b
#toma el valor de c y lo multiplica por el valor de b para reasignarlo a la variable c. Es decir c = 23 * 5. El resultado es 115
c&d
#toma el valor binario de la variable c y realiza una operacion logica de conjuncion con el valor binario de la variable d. En este caso, el resultado es 1
c|d
#toma el valor binario de la variable c y realiza una operacion logica de disyuncion  con el valor binario de la variable d. En este caso, el resultado es 1
c&c
#Esta operacion realiza una conjuncion logica del valor de c consigo mismo. Esto es igual que tomar el valor binario de la variable c. El resultado es 1
d|d
#Se realiza una disyuncion logica del valor de d consigo mismo. Esto es igual que tomar el valor binario de la variable d. El resultado es 1


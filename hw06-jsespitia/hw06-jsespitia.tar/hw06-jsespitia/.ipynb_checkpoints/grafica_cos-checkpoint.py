import matplotlib.pyplot as plt
import math
import sys

def graficar(t,n):
    A = list( range(0,100))
    x = []
    for elemento in A:
        x.append( t + elemento * 2 * 3.1416 / 100 )

    y = []
    for elemento in x:
        y.append( math.cos(elemento))

    plt.subplot(111)
    plt.axis("equal")
    plt.plot(x,y)    
    plt.title('t = {}'.format(t))
    plt.savefig('{}.png'.format(n))
    plt.close()

